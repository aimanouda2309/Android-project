package com.example.mypracticalpartapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DraftAdapter extends RecyclerView.Adapter<DraftAdapter.ViewHolder> {
    private List<DraftMessage> Drafts = new ArrayList<>();
    private static Context context;
    public DraftAdapter(List<DraftMessage> Drafts, Context context) {

        this.context = context;
        this.Drafts = Drafts;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_vew1, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DraftMessage item = Drafts.get(position);
        holder.bindData(item,this);
    }

    @Override
    public int getItemCount() {
        return Drafts.size();
    }

    @Override
    public int getItemViewType(int position)
    {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView number, msg;
        private RelativeLayout msg_container;
        private ImageView profile;
        private View view;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.textView);
            msg = itemView.findViewById(R.id.textView2);
            profile = (ImageView) itemView.findViewById(R.id.imageView);
            view = itemView;
            msg_container = (RelativeLayout) itemView.findViewById(R.id.msg_container);
        }

        public void bindData(final DraftMessage item, DraftAdapter adap) {
            profile.setAnimation(AnimationUtils.loadAnimation(DraftAdapter.context,R.anim.fade_transition));
            msg_container.setAnimation(AnimationUtils.loadAnimation(DraftAdapter.context,R.anim.scale));


            number.setText(item.phoneNumber);
            msg.setText(item.Message);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(DraftAdapter.context);

                    builder.setTitle("Confirm");
                    builder.setMessage("Are you sure to Send this Message to " + item.phoneNumber);
                    builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            Uri deleteUri = Uri.parse("content://sms");

                            SmsManager sms = SmsManager.getDefault();
                            sms.sendTextMessage(item.phoneNumber, null, item.Message, null, null);
                            dialog.dismiss();

                            AppDatabase appDB = AppDatabase.getInstance(DraftAdapter.context);
                            appDB.draftDao().delete(item.uid);


                            ViewPagerAdapter.listener.notifyDataSetChanged();

                            Drafts.remove(getPosition());
                            notifyDataSetChanged();
                            dialog.dismiss();
                        }
                    });

                    builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            // Do nothing
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alert = builder.create();
                    alert.show();

                }
            });

        }

    }
}
