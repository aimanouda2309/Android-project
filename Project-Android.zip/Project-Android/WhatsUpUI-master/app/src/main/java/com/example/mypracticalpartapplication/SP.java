package com.example.mypracticalpartapplication;

import android.content.Context;
import android.content.SharedPreferences;

public class SP {
    public static String ID = "DELETED";
    public static String READ = "READ";
    public static String PREF = "PREF";
    public static SharedPreferences pref;
    public static Context context;

    public SP(Context context) {
       SP.context = context;
    }
    public static void save_ids(String ids){
        SharedPreferences pref = SP.context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(ID,ids);
        editor.apply();

    }
    public static String load_Data(){
        SharedPreferences pref = SP.context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String ret = pref.getString(ID,"");
        return ret;
    }
    public static void save_checkbox(Boolean check){
        SharedPreferences pref = SP.context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putBoolean("check",check);
        editor.apply();

    }
    public static Boolean load_check(){
        SharedPreferences pref = SP.context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        return pref.getBoolean("check",false);
    }
    public static void save_ids_read(String ids){
        SharedPreferences pref = SP.context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(READ,ids);
        editor.apply();
    }
    public static String load_Data_Read(){
        SharedPreferences pref = SP.context.getSharedPreferences(PREF,Context.MODE_PRIVATE);
        String ret = pref.getString(READ,"");
        return ret;
    }

}
