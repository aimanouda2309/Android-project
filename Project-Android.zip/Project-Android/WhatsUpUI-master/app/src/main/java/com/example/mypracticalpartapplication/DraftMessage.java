package com.example.mypracticalpartapplication;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class DraftMessage {
    @PrimaryKey(autoGenerate = true)
    public int uid;

    @ColumnInfo(name = "Phone")
    public String phoneNumber;

    @ColumnInfo(name = "Msg")
    public String Message;

    public DraftMessage(int uid, String phoneNumber, String Message) {
        this.uid = uid;
        this.phoneNumber = phoneNumber;
        this.Message = Message;
    }

    @Ignore
    public DraftMessage(String phoneNumber, String message) {
        this.phoneNumber = phoneNumber;
        Message = message;
    }
}