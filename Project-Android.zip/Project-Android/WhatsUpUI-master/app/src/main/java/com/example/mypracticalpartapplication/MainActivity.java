package com.example.mypracticalpartapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.preference.PreferenceFragmentCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.viewpager.widget.ViewPager;
import android.Manifest;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceFragment;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

public class MainActivity extends AppCompatActivity implements MyAlertDialogFragment.OnDialogFragmentClickListener {
    private TabLayout tabLayout;
    public static ViewPager viewPager;
    public static ViewPagerAdapter viewPagerAdapter;
    public static final int RequestPermissionCode = 1;
    public static  ArrayList<Fragment> fragmentList = new ArrayList<>();
    //floatings
    private FloatingActionButton fab,fab2,fab3;
    private Animation fab_open,fab_close,f_rotate,b_rotate;
    private Boolean is_fabs_opened=Boolean.FALSE;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar tool=findViewById(R.id.toolbar);
        tool.setTitle("");
        setSupportActionBar(tool);
        fab3 = findViewById(R.id.fab3);



        //
        //get sms for service
        getSMS getsms = new getSMS(this);


        SP sp = new SP(this);
        Boolean b = SP.load_check();
        if(b){
            fab3.setImageResource(R.drawable.deleteyes);
        }else{
            fab3.setImageResource(R.drawable.bindelete);
        }
        //////////////////////
        fab = findViewById(R.id.fab);
        fab2 = findViewById(R.id.fab2);


        fab_open = AnimationUtils.loadAnimation(this,R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(this,R.anim.fab_close);
        f_rotate = AnimationUtils.loadAnimation(this,R.anim.f_rotate);
        b_rotate = AnimationUtils.loadAnimation(this,R.anim.b_rotate);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fab_animate();
            }
        });

        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyAlertDialogFragment newFragment = MyAlertDialogFragment.newInstance();
                newFragment.show(getFragmentManager(), "dialog");
            }
        });

        fab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

/*
                getSupportFragmentManager()
                        .beginTransaction()
                        .addToBackStack("b")
                        .replace(R.id.main_container, new PerfFragment())
                        .commit();*/
                //fab3.setClickable(false);
                //fab2.setClickable(false);
                //fab.setClickable(false);

                Boolean b = SP.load_check();
                if(b){
                    SP.save_checkbox(false);
                    fab3.setImageResource(R.drawable.bindelete);
                    Toast.makeText(MainActivity.this, "Unrecover Mode", Toast.LENGTH_SHORT).show();
                }else{
                    SP.save_checkbox(true);
                    fab3.setImageResource(R.drawable.deleteyes);
                    Toast.makeText(MainActivity.this, "Recover Mode", Toast.LENGTH_SHORT).show();
                }
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        ViewPagerAdapter.listener.notifyDataSetChanged();
                    }
                }, 100);

            }
        });
        if(checkPermission()){
            if (!isMyServiceRunning(ForegroundService.class)){
                Intent serviceIntent = new Intent(this, ForegroundService.class);
                serviceIntent.putExtra("inputExtra", "Foreground Service Example in Android");
                ContextCompat.startForegroundService(this, serviceIntent);
            }


            //
            //broad cast reciver!
            BroadcastReceiver br = new MyBroadcastReceiver();
            IntentFilter filter = new IntentFilter();
            filter.addAction("android.provider.Telephony.SMS_RECEIVED");
            registerReceiver(br, filter);
            //Toast.makeText(MainActivity.this, "All Permissions Granted Successfully", Toast.LENGTH_LONG).show();
            tabLayout = findViewById(R.id.tab_layout);
            viewPager = findViewById(R.id.viewpager);
            tabLayout.setupWithViewPager(viewPager);
            final int REQUEST_CODE_ASK_PERMISSIONS = 123;



            List<String> titleList = new ArrayList<>();
            titleList.add("Received");
            titleList.add("Sent");
            titleList.add("Drafts");

            fragmentList.add(new ChatFragment());
            fragmentList.add(new ChatSentFragment());
            fragmentList.add(new StatusFragment());

            viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), 1, fragmentList, titleList);
            viewPager.setAdapter(viewPagerAdapter);


        }
        else {

            requestPermission();
        }



    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    private void fab_animate(){
        if(is_fabs_opened){
            fab.startAnimation(b_rotate);
            fab2.startAnimation(fab_close);
            fab3.startAnimation(fab_close);
            fab2.setClickable(false);
            fab3.setClickable(false);
            is_fabs_opened = false;
        }else{
            fab.startAnimation(f_rotate);
            fab2.startAnimation(fab_open);
            fab3.startAnimation(fab_open);
            fab2.setClickable(true);
            fab3.setClickable(true);
            is_fabs_opened = true;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
       getMenuInflater().inflate(R.menu.option_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.Exitid:
            System.exit(0);
            return true;
            case R.id.Aboutid:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Ayman Odeh  316546092\nSami Odeh")
                        .setCancelable(false)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //do things
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public boolean checkPermission() {

        int FirstPermissionResult = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_CONTACTS);
        int sec =ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.READ_SMS);
        int third  =ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.SEND_SMS);
        int fourth  =ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.RECEIVE_SMS);


        return FirstPermissionResult == PackageManager.PERMISSION_GRANTED
                && sec == PackageManager.PERMISSION_GRANTED &&
                third == PackageManager.PERMISSION_GRANTED && fourth== PackageManager.PERMISSION_GRANTED;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {

            case RequestPermissionCode:

                if (grantResults.length > 0) {

                    boolean conPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                    boolean smsPermission = grantResults[1] == PackageManager.PERMISSION_GRANTED;
                    boolean smsSendPermission = grantResults[2] == PackageManager.PERMISSION_GRANTED;
                    boolean smsRecPermission=grantResults[3] == PackageManager.PERMISSION_GRANTED;
                    if (conPermission && smsPermission && smsSendPermission&& smsRecPermission) {
                        if (!isMyServiceRunning(ForegroundService.class)){
                            Intent serviceIntent = new Intent(this, ForegroundService.class);
                            serviceIntent.putExtra("inputExtra", "Foreground Service Example in Android");
                            ContextCompat.startForegroundService(this, serviceIntent);
                        }


                        //
                        //broad cast reciver!
                        BroadcastReceiver br = new MyBroadcastReceiver();
                        IntentFilter filter = new IntentFilter();
                        filter.addAction("android.provider.Telephony.SMS_RECEIVED");
                        registerReceiver(br, filter);
                        Toast.makeText(MainActivity.this, "Permission Granted", Toast.LENGTH_LONG).show();
                        tabLayout = findViewById(R.id.tab_layout);
                        viewPager = findViewById(R.id.viewpager);
                        tabLayout.setupWithViewPager(viewPager);



                        List<String> titleList = new ArrayList<>();
                        titleList.add("Received");
                        titleList.add("Sent");
                        titleList.add("Drafts");
                        List<Fragment> fragmentList = new ArrayList<>();
                        fragmentList.add(new ChatFragment());
                        fragmentList.add(new ChatSentFragment());
                        fragmentList.add(new StatusFragment());

                        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager(), 1, fragmentList, titleList);
                        viewPager.setAdapter(viewPagerAdapter);

                    }
                    else {
                        Toast.makeText(MainActivity.this,"Permission Denied",Toast.LENGTH_LONG).show();

                    }
                }

                break;
        }
    }
    private void requestPermission() {

        ActivityCompat.requestPermissions(MainActivity.this, new String[]
                {
                        Manifest.permission.READ_CONTACTS,Manifest.permission.READ_SMS,Manifest.permission.SEND_SMS,Manifest.permission.RECEIVE_SMS
                }, RequestPermissionCode);

    }

    @Override
    public void onOkClicked_seek(DialogInterface dialog, String number, String msg) {
        Uri deleteUri = Uri.parse("content://sms");

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(number, null, msg, null, null);
        dialog.dismiss();
        ViewPagerAdapter.listener.notifyDataSetChanged();
    }

    @Override
    public void onCancelClicked_seek(DialogInterface dialog,String number,String msg) {
        if(!(number.equals("") || msg.equals(""))){
            AppDatabase appDB = AppDatabase.getInstance(this);
            DraftMessage msgDraft = new DraftMessage(number,msg);
            appDB.draftDao().insert(msgDraft);
            ViewPagerAdapter.listener.notifyDataSetChanged();
        }
    }


}
