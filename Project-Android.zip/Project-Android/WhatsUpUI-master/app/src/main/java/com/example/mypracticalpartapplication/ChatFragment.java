package com.example.mypracticalpartapplication;

import android.Manifest;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class ChatFragment extends Fragment  {
    private RecyclerView recyclerView;
    private CustomAdapter customAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chat, container, false);
        ArrayList<Messages> users = new ArrayList<>();
        users = getAllSms();
        //Toast.makeText(getActivity(), users.get(1).getFolderName(), Toast.LENGTH_LONG).show();
        recyclerView = view.findViewById(R.id.recycler_view);
        customAdapter = new CustomAdapter(users, getContext(),false);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(customAdapter);




            return view;
    }



    public ArrayList<Messages> getAllSms() {
        ArrayList<Messages> lstSms = new ArrayList<Messages>();
        Messages objSms = new Messages(null);
        Uri message = Uri.parse("content://sms/");
        ContentResolver cr = getActivity().getContentResolver();
        ArrayList<String> deleted = new ArrayList<String>();
        int toRecover_or_not = 0;

        //check if there is messages to recover from SP
        if(SP.load_check()){
            toRecover_or_not = 1;
        }else {
            toRecover_or_not = 0;
            // Toast.makeText(getActivity(), "teeeeeeest", Toast.LENGTH_LONG).show();
            String delt = SP.load_Data();

            String[] splitted = delt.split(",");
            Log.i("len", splitted.length + "");
            for (int j = 0; j < splitted.length; j++) {
                deleted.add(splitted[j]);
                Log.i("f", splitted[j]);
            }
        }
        //
        Cursor c = cr.query(message, null, null, null, null);
        getActivity().startManagingCursor(c);
        int totalSMS = c.getCount();

        if (c.moveToFirst()) {
            for (int i = 0; i < totalSMS; i++) {

                objSms = new Messages(null);
                objSms.setId(c.getString(c.getColumnIndexOrThrow("_id")));
                objSms.setAddress(c.getString(c
                        .getColumnIndexOrThrow("address")));
                objSms.setMsg(c.getString(c.getColumnIndexOrThrow("body")));
                objSms.setReadState(c.getString(c.getColumnIndex("read")));
                objSms.setTime(c.getString(c.getColumnIndexOrThrow("date")));
                if (c.getString(c.getColumnIndexOrThrow("type")).contains("1")) {
                    objSms.setFolderName("inbox");
                } else {
                    objSms.setFolderName("sent");
                }

                    if(objSms.getFolderName().equals("inbox")){
                        if(toRecover_or_not == 1){
                            lstSms.add(objSms);
                        }else{
                            if(!deleted.contains(objSms.getId())){
                                lstSms.add(objSms);
                            }
                        }
                    }

                c.moveToNext();

            }
        }

        //c.close();

        return lstSms;
    }


}
