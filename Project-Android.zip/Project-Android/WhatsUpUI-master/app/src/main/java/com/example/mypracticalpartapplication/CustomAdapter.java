package com.example.mypracticalpartapplication;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {
    private List<Messages> userList = new ArrayList<>();
    private static Context context;
    private Boolean check;
   // private Boolean is_Sent; //1 sent, 0 recieved

    public CustomAdapter(List<Messages> userList, Context context, Boolean check) {

        this.context = context;
        this.userList = userList;
        this.check = check;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_vew, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Messages item = userList.get(position);
        holder.bindData(item,this);
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    @Override
    public int getItemViewType(int position)
    {
        return position;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView number, msg,date;
        private RelativeLayout msg_container;
        private ImageView profile;
        private View view;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.textView);
            msg = itemView.findViewById(R.id.textView2);
            date = itemView.findViewById(R.id.textView3);
            profile = (ImageView) itemView.findViewById(R.id.imageView);
            view = itemView;
            msg_container = (RelativeLayout) itemView.findViewById(R.id.msg_container);
        }

        public void bindData(final Messages item, CustomAdapter adap) {
            profile.setAnimation(AnimationUtils.loadAnimation(CustomAdapter.context,R.anim.fade_transition));
            msg_container.setAnimation(AnimationUtils.loadAnimation(CustomAdapter.context,R.anim.scale));


            number.setText(item.getAddress());
            msg.setText(item.getMsg());
            long milliSeconds = Long.parseLong(item.getTime());
            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm");
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(milliSeconds);
            String finalDateString = formatter.format(calendar.getTime());
            date.setText(finalDateString);

            //read message
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setMessage(item.getMsg())
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    //do things
                                    if(!check){
                                        SP.save_ids_read(SP.load_Data_Read()+ "," + item.getId());
                                    }

                                    //Toast.makeText(CustomAdapter.context, SP.load_Data_Read(), Toast.LENGTH_LONG).show();
                                    dialog.dismiss();
                                }
                            });
                    AlertDialog alert = builder.create();
                    alert.show();
                }
            });
            //delete message
            view.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(CustomAdapter.context);

                    builder.setTitle("Confirm");
                    builder.setMessage("Are you sure to delete this message?");

                    builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {
                            SP.save_ids(SP.load_Data()+ "," + item.getId());
                            userList.remove(getPosition());
                            notifyDataSetChanged();
                            dialog.dismiss();
                        }
                    });

                    builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            // Do nothing
                            dialog.dismiss();
                        }
                    });

                    AlertDialog alert = builder.create();
                    alert.show();
                    return false;
                }
            });
        }

    }
}
