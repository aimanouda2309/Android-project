package com.example.mypracticalpartapplication;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TaskStackBuilder;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ForegroundService extends Service {
    public static final String CHANNEL_ID = "ForegroundServiceChannel";
    NotificationManager mNotiMgr;
    Notification.Builder mNotifyBuilder;
    Runnable test;
    MediaPlayer mp;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate() {
        super.onCreate();
        initForeground();
        mp = MediaPlayer.create(this, R.raw.vibrate);
        mp.setLooping(false);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String input = intent.getStringExtra("inputExtra");

        //stopSelf();
        startForeground(1, updateNotification(Integer.toString(0)));

        final Handler handler = new Handler();
        test = new Runnable() {
            @Override
            public void run() {
                String delt = SP.load_Data_Read();
                ArrayList<String> already_read = new ArrayList<String>();
                ArrayList<Messages> msgs = new ArrayList<Messages>();
                String[] splitted = delt.split(",");
                for (int j = 0; j < splitted.length; j++) {
                    already_read.add(splitted[j]);
                }
                msgs = getSMS.getAllSms();
                int count = 0;
                for(Messages msg : msgs){
                    if(!already_read.contains(msg.getId())){
                        count++;
                    }
                }
                if(count > 0){
                    //vibrate_phone();
                    mp.start();
                }
                updateNotification(count + "");
                handler.postDelayed(test, 5000); //100 ms you should do it 4000
            }
        };

        handler.postDelayed(test, 0);




        return START_STICKY;
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void initForeground(){
        String CHANNEL_ID = "my_channel_01";
        if (mNotiMgr==null)
            mNotiMgr= (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "My main channel",
                NotificationManager.IMPORTANCE_DEFAULT);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE))
                .createNotificationChannel(channel);

        mNotifyBuilder = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("New Messages")
                .setSmallIcon(R.drawable.user)
                .setAutoCancel(true);

    }
    public void vibrate_phone(){
        if (Build.VERSION.SDK_INT >= 26) {
            ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(VibrationEffect.createOneShot(150, VibrationEffect.EFFECT_HEAVY_CLICK));
        } else {
            ((Vibrator) getSystemService(VIBRATOR_SERVICE)).vibrate(150);
        }
    }
    public Notification updateNotification(String details){
        mNotifyBuilder.setContentText(details).setOnlyAlertOnce(false);
        Notification noti = mNotifyBuilder.build();
        noti.flags = Notification.FLAG_ONLY_ALERT_ONCE;
        mNotiMgr.notify(1, noti);
        return noti;
    }


}