package com.example.mypracticalpartapplication;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MyAlertDialogFragment extends DialogFragment {


    OnDialogFragmentClickListener listner;

    public interface OnDialogFragmentClickListener {
        public void onOkClicked_seek(DialogInterface dialog,String number,String msg);
        public void onCancelClicked_seek(DialogInterface dialog,String number,String msg);
    }

    public static MyAlertDialogFragment newInstance() {
        MyAlertDialogFragment frag = new MyAlertDialogFragment();
        //Bundle args = new Bundle();
        //args.putInt("seek", seek);
        //frag.setArguments(args);
        return frag;
    }


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {


        View mylayout = getActivity().getLayoutInflater().inflate(R.layout.send_message,null);
        final AutoCompleteTextView editText = mylayout.findViewById((R.id.autoCompleteTextView));
        final EditText msgEdit = mylayout.findViewById(R.id.editTextmsg);
        ArrayList<Contact> Contacts = getContacts();
        AutoCompleteContactAdapter adapter = new AutoCompleteContactAdapter(getActivity(),Contacts);
        editText.setAdapter(adapter);




        return new AlertDialog.Builder(getActivity())
                .setTitle("Send new Message")
                .setView(mylayout)
                .setPositiveButton("Send",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                String phone = editText.getText().toString();
                                String msgtext = msgEdit.getText().toString();
                                listner.onOkClicked_seek(dialog,phone,msgtext);
                            }
                        }
                )
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                listner.onCancelClicked_seek(dialog,editText.getText().toString(),msgEdit.getText().toString());
                            }
                        }
                )
                .create();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {

        try{
            this.listner = (OnDialogFragmentClickListener)getActivity();
        }catch(ClassCastException e){
            throw new ClassCastException("the class " +
                    getTargetFragment().getClass().getName() +
                    " must implements the interface 'OnDialogFragmentClickListenerSeek'");
        }
        super.onActivityCreated(savedInstanceState);

    }


    public ArrayList<Contact> getContacts(){
        ArrayList<Contact> Contacts = new ArrayList<Contact>();
        Cursor phones = getActivity().getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,null,null, null);
        while (phones.moveToNext())
        {
            String name=phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
            String phoneNumber = phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
            Contacts.add(new Contact(name,phoneNumber));
        }

        phones.close();

        return Contacts;
    }

}