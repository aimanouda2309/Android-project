package com.example.mypracticalpartapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

class AutoCompleteContactAdapter extends ArrayAdapter<Contact> {
    private ArrayList<Contact> Contacts;
    public AutoCompleteContactAdapter(Context context, ArrayList<Contact> Contacts) {
        super(context,0, Contacts);
        this.Contacts = new ArrayList<Contact>(Contacts);
    }

    @NonNull
    @Override
    public Filter getFilter() {
        return ContactFilter;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.contact,parent,false);
        }
        TextView textnumber = convertView.findViewById(R.id.textView);
        Contact contactitem = getItem(position);
        if(contactitem != null){
            textnumber.setText(contactitem.getPhone());
        }
        return convertView;
    }

    public Filter ContactFilter = new Filter(){

        @Override
        protected FilterResults performFiltering(CharSequence charSequence) {
            FilterResults results = new FilterResults();
            ArrayList<Contact> suggestions = new ArrayList<Contact>();
            if(charSequence == null || charSequence.length()== 0){
                suggestions.addAll(Contacts);
            }else{
                String filterPattern = charSequence.toString();
                for(Contact item : Contacts){
                    if (item.getPhone().contains(charSequence)) {
                        suggestions.add(item);
                    }
                }
            }
            results.values = suggestions;
            results.count = suggestions.size();
            return results;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            clear();
            addAll((List)filterResults.values);
            notifyDataSetChanged();
        }

        @Override
        public CharSequence convertResultToString(Object resultValue) {
            return ((Contact)resultValue).getPhone();
        }
    };
}
