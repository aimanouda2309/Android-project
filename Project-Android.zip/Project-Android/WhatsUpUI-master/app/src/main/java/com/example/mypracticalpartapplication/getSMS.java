package com.example.mypracticalpartapplication;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import java.util.ArrayList;

public class getSMS {
    public static Context context;
    public getSMS(Context context) {
        this.context =context;
    }

    public static ArrayList<Messages> getAllSms() {
        ArrayList<Messages> lstSms = new ArrayList<Messages>();
        Messages objSms = new Messages(null);
        Uri message = Uri.parse("content://sms/");
        ContentResolver cr = context.getContentResolver();
        ArrayList<String> deleted = new ArrayList<String>();

        Cursor c = cr.query(message, null, null, null, null);
        ((Activity) context).startManagingCursor(c);
        int totalSMS = c.getCount();

        if (c.moveToFirst()) {
            for (int i = 0; i < totalSMS; i++) {

                objSms = new Messages(null);
                objSms.setId(c.getString(c.getColumnIndexOrThrow("_id")));
                objSms.setAddress(c.getString(c
                        .getColumnIndexOrThrow("address")));
                objSms.setMsg(c.getString(c.getColumnIndexOrThrow("body")));
                objSms.setReadState(c.getString(c.getColumnIndex("read")));
                objSms.setTime(c.getString(c.getColumnIndexOrThrow("date")));
                if (c.getString(c.getColumnIndexOrThrow("type")).contains("1")) {
                    objSms.setFolderName("inbox");
                } else {
                    objSms.setFolderName("sent");
                }

                if(objSms.getFolderName().equals("inbox")){
                    lstSms.add(objSms);
                }

                c.moveToNext();
            }
        }

        //c.close();

        return lstSms;
    }

}
