package com.example.mypracticalpartapplication;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.ArrayList;
import java.util.List;

@Dao
public interface DraftDao {
    @Query("SELECT * FROM DraftMessage")
    List<DraftMessage> getAllDrafts();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(DraftMessage draft);

    @Query("Delete from DraftMessage where uid=:id")
    int delete(int id);

    @Query("DELETE FROM DraftMessage")
    public void DeleteAll();

}